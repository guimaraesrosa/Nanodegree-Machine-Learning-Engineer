Proposta do Trabalho Final - Machine Learning

1. proposta.pdf - detalhes do projeto
2. TSEM_A.CSV - base de dados com informações do paciente
3. TSUM_B.CSV - base de dados com informações dos exames laboratoriais
